### v1.0.4 - `26/08/2015, 2:57pm`
#### add tag to info.json for styleguide filtering  
* add tag to info.json for styleguide menu filtering  


### v1.0.3 - `11/08/2015, 5:41pm`
#### Fix model.xml format.  
* LF-211: Add model.xml for feature definition.  


### v1.0.2 - `11/08/2015, 1:38pm`
#### Add model.xml for feature definition.  


### v1.0.1 - `10/08/2015, 6:05pm`
#### Remove repository from bower.json  


### v1.0.0 - `27/07/2015, 11:20am`
#### Initial release  
