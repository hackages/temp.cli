# Behaviors module

# Information

| name                  | version       | bundle     |
| ----------------------|:-------------:| ----------:|
| module-behaviors         | 1.0.4         | launchpad  |

## Dependencies

## Dev Dependencies
