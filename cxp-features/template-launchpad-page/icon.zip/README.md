# Launchpad Page Template
Generic launchpad page template

![icon](./icon.png)

