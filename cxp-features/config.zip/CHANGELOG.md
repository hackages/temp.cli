### v3.4.0 - `21/10/2015, 2:42pm`
* NGUSEOLB-579: Add user agent external lib path  
* Added bbAmount module path.  

### v3.3.0 - `15/10/2015, 12:30pm`
#### Added extended configuration for RequireJS including new ui-base and components.  

### v3.2.5 - `02/10/2015, 12:23pm`
* fix typo  

### v3.2.4 - `02/10/2015, 11:43am`
* add module-cards to requirejs.conf  
* LF-376: migrated p2pService to lpP2P  

### v3.2.3 - `30/09/2015, 3:17pm`
* deps paths are fixed;
* IE8 polyfills are added
* LF-376: migrated p2pService to lpP2P

### v3.2.1 - `26/08/2015, 2:57pm`
#### add tag to info.json for styleguide filtering
* add tag to info.json for styleguide menu filtering


### v3.2.0 - `11/08/2015, 10:41am`
#### show wanrning log in case of unminified
* small changes to default module path, show warnings instead of info

### v3.1.3 - `11/08/2015, 5:41pm`
#### Fix model.xml format.
* LF-211: Add model.xml for feature definition.

### v3.1.2 - `11/08/2015, 1:38pm`
#### Add model.xml for feature definition.

### v3.1.1 - `10/08/2015, 6:05pm`
#### Remove repository from bower.json


### v3.1.0 - `10/08/2015, 2:59pm`
#### Clean up widget-transactions-new and module-transactions-2.


### v3.0.0 - `29/07/2015, 5:25pm`
- LF-155: update require.config for 5.6

### [2.0.8]
- add default use min option for usemin: true
- register module-currencies for workshop

### [2.0.7]
- Take USEMIN setting from window.launchpad.config.usemin.

### [2.0.5]
- add requirejs.undef for jquery and angular they are loaded as script tags

### [2.0.0] - 2015-05-12 (note: generated from git logs)
- LPES-3657: i18n: added sk-SK
- add angular ad AMD module from window
- LPES-0000 i18n: negative currency format for en-US changed to "-¤xx.xx"
- LPES-0000 i18n: added sk-SK
- Make requirejs config decide automatically which module path to use based on the environment.

### [1.0.0]
* Initial release
