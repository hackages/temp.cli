/**
 * Launchpad global configuration file
 * @param  {[type]} require [description]
 * @param  {[type]} exports [description]
 * @param  {String} module) {                    exports.NS [description]
 * @return {[type]}         [description]
 */
define(function(require, exports, module) {
    'use strict';
     // global Namespace and modules / widgets namespace
    exports.NS = 'launchpad';

});
