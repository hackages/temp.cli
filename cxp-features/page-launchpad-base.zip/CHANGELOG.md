### v1.0.4 - `22/12/2015, 5:07pm`
* LF-728: Added page http cache invalidate timeout property

### v1.0.3 - `20/08/2015, 5:26pm`
* Update default theme to theme-default.
* Updating dependencies from master to ^1.0.0 in bower.json


### v1.0.2 - `20/08/2015, 4:16pm`
* Updating dependencies from master to ^1.0.0 in bower.json


### v1.0.1 - `10/08/2015, 6:09pm`
#### Remove repository from bower.json
* update bower
* Add template-launchpad-page as dependency.
* add icon and Readme
