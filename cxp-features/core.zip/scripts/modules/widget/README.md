# widget

Core widget provider contains `useWidgetInstance` for preconfigure application services, like `lpWidget` & `widget`. Also, extends widget instance model with method `getResolvedPreference`.

## lpWidget

Service returns widget instance model for further usage.

## widget

Angular value service, contains widget instance model. Will be deprecated.
