### v1.0.15 - `11/01/2016, 11:50am`
* build for launcher deck  

### v1.0.14 - `05/01/2016, 9:55am`
* LF-749: Accounts tiles layout made themable.
* LF-749: Accounts tree layout made themable.

### v1.0.13 - `30/12/2015, 4:01pm`
* LF-751: Rebuild after updating message center.

### v1.0.12 - `20/11/2015, 11:43am`
* Apply last changes from the base theme  

### v1.0.11 - `20/10/2015, 12:10pm`
* NGUSEOLB-626: rebuild default theme, based on new base theme. Fix for transaction search  

### v1.0.10 - `28/09/2015, 11:41am`
* DOCS: Added info.json to the list of files to edit.  
* Update theme docs.  

### v1.0.9 - `22/09/2015, 11:44am`
#### LF-302: fix account selector for Springboard container - rebuild default theme  


### v1.0.8 - `11/09/2015, 3:24pm`
* LF-300: Update to theme 4.0.0, which uses 'retail' instead of 'banking' edition.  


### v1.0.7 - `26/08/2015, 2:57pm`
#### add tag to info.json for styleguide filtering  
* add tag to info.json for styleguide menu filtering  


### v1.0.5 - `20/08/2015, 2:05pm`
#### Fix relative path.  
* Recompile with correct relative path the theme.  


### v1.0.4 - `20/08/2015, 2:04pm`
* Recompile with correct relative path the theme.  
* Made theme a dependency, instead of dev-dependency.  
* Change bower name.  


### v1.0.3 - `20/08/2015, 12:46pm`
* Made theme a dependency, instead of dev-dependency.  
* Change bower name.  
