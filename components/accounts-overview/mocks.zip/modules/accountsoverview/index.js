import accountsOverviewList from './accountsoverviewlist';

export default angular.module('crelan.accounts.overview', [accountsOverviewList]).name;