module.exports = function Widget () {
    this.getPreference = function() {};
    this.getResolvedPreference = function() {};
    this.addEventListener = function() {};
    this.getPreferenceFromParents = function() {};
};
