function Model() {

}

Model.prototype.config = function() {};

Model.prototype.load = function() {
    return {
        then: function() {}
    };
};

module.exports = Model;
