import digipassChooser from './digipasschooserdirective';

export default angular.module('crelan.digipassChooser', [digipassChooser]).name;