import account from './accountDirective';

export default angular.module('account', [account]).name;