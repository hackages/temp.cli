import helloWorld from './helloWorldDirective';

export default angular.module('helloWorld', [helloWorld]).name;