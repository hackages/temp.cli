import helloWorld from './helloworlddirective';

export default angular.module('helloWorld', [helloWorld]).name;