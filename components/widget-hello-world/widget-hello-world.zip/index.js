import account from './modules/account';

angular.module('app', [account]);

