import angular from 'angular';
import 'angular-mocks';

 let module = angular.module('mocks', ['ngMockE2E'])
  .run(function($httpBackend){
    $httpBackend.whenGET('/mocks/messages').respond(getBooks());

    $httpBackend.whenGET().passThrough();
  });


export default module.name;
