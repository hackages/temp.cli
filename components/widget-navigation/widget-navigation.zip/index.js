import navigation from './modules/navigation';

angular.module('app', [navigation]);
