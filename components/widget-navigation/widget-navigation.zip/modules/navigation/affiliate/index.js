import affiliate from './affiliateDirective';

export default angular.module('affiliate', [affiliate]).name;