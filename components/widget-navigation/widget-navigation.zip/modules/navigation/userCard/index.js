import userCard from './userCardDirective';

export default angular.module('userCard', [userCard]).name;