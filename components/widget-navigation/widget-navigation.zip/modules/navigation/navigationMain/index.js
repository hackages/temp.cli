import navMain from './navMainDirective';

export default angular.module('navMain', [navMain]).name;