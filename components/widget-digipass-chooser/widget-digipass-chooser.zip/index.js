import digipasschooser from './modules/digipasschooser';
/*import mocks from './mocks';*/

angular.module('app', [digipasschooser/*, mocks*/]);

document.addEventListener('DOMContentLoaded', function () {
  angular.bootstrap(document.body, ['app']);
});