import digipassChooser from './digipasschooserdirective';

export default angular.module('digipassChooser', [digipassChooser]).name;