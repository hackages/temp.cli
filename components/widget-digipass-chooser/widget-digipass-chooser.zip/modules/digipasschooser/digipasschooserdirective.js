import angular from 'angular/index.js';
import digipassTemplate from './digipass.html';
/*import digipassChooserService from './services/digipasschooserservice';*/

let module = angular.module('digipassChooserDirective', [/*digipassChooserService*/])
  .directive('digipassChooser', digipassChooserDirective);
export default module.name;

function digipassChooserDirective(){
  return {
    restrict: 'EA',
    template: digipassTemplate,
    scope: {}
  }
}