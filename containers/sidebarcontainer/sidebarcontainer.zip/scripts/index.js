/**
 * Created by u122415 on 20/05/2016.
 */
//document.addEventListener('DOMContentLoaded', function () {
  window.counter = window.counter || 0;

  console.log('inside loader', window.counter);
  angular.module('crelanApp', []);
//});