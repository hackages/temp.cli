### `v1.1.1 - 31/03/2016`

### v1.1.0 - `05/01/2016, 1:30pm`
* fix classes for 2nd level tabs  
* separate tabs template, add 2nd level  

### v1.0.1 - `20/08/2015, 3:49pm`
* Updating dependencies from master to ^1.0.0 in bower.json  


### v1.0.0 - `20/08/2015, 2:38pm`
#### Initial release for CXP 5.6  


### v0.1.1 - `10/08/2015, 6:10pm`
#### Remove repository from bower.json  
* fix launcher  
