# Panel Container
Generic empty panel which can be added to a Deck Container as a child.

![icon](./icon.png)

## Information
|  name |  version |  bundle |
|--|:--:|--:|
|  container-panel |  1.0.3 |  Universal |

