### `v1.0.3 - 31/03/2016`

### v1.0.2 - `26/08/2015, 12:16pm`
#### add tag to info.json for styleguide filtering  
* add tag to info.json for styleguide menu filtering  


### v1.0.1 - `20/08/2015, 3:48pm`
* Updating dependencies from master to ^1.0.0 in bower.json  


### v1.0.0 - `20/08/2015, 2:38pm`
#### Initial release for CXP 5.6  


### v0.2.2 - `10/08/2015, 6:09pm`
#### Remove repository from bower.json  
* fix link  
* fix panel container  
* rename panel container name  
* remove unused js dependencies  
* unify template call  
* Fix template.js link.  


### v0.2.1 - `31/07/2015, 1:17pm`
#### Update for fixes on template.  
* add template dependency  


### v0.2.0 - `30/07/2015, 2:46pm`
* Moving templates to their own repos.  
* update readme  
