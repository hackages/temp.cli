### `v1.0.3 - 31/03/2016`
* LF-747: panel template renamed
* LF-747: panel template renamed

### v1.0.2 - `24/12/2015, 10:12am`
* LF-747: panel template renamed

### v1.0.1 - `20/08/2015, 3:49pm`


### v1.0.0 - `20/08/2015, 2:38pm`
#### Initial release for CXP 5.6  


### v0.1.2 - `10/08/2015, 6:10pm`
#### Remove repository from bower.json  
* rename template  


### v0.1.1 - `31/07/2015, 1:16pm`
#### Initial release  
