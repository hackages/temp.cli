# DeckContainer
Generic container for holding several panels which can be shown one at a time. Being inherited by Tabs and Launcher container.

![icon](./icon.png)

## Information
|  name |  version |  bundle |
|--|:--:|--:|
|  container-deck |  1.1.2 |  Universal |

